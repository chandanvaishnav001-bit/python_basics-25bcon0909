"""
Program demonstrating Python's core data structures:
List, Tuple, Set, and Dictionary.
"""


def demonstrate_list():
    print("\n--- LIST ---")
    fruits = ["apple", "banana", "cherry"]
    fruits.append("mango")
    fruits.remove("banana")
    print("List:", fruits)
    print("Element at index 1:", fruits[1])


def demonstrate_tuple():
    print("\n--- TUPLE ---")
    coordinates = (10, 20, 30)
    print("Tuple:", coordinates)
    print("Element at index 0:", coordinates[0])
    # Tuples are immutable, so no add/remove operations


def demonstrate_set():
    print("\n--- SET ---")
    numbers = {1, 2, 3, 3, 4}
    numbers.add(5)
    numbers.discard(2)
    print("Set (duplicates removed automatically):", numbers)


def demonstrate_dictionary():
    print("\n--- DICTIONARY ---")
    student = {"name": "Riya", "age": 21, "course": "CS"}
    student["grade"] = "A"
    del student["age"]
    print("Dictionary:", student)
    for key, value in student.items():
        print(f"  {key}: {value}")


if __name__ == "__main__":
    demonstrate_list()
    demonstrate_tuple()
    demonstrate_set()
    demonstrate_dictionary()
