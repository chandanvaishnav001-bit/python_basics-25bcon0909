"""
Program to generate the Fibonacci sequence.
Each number is the sum of the two preceding ones: 0, 1, 1, 2, 3, 5, 8, ...
"""


def fibonacci_recursive(n):
    """Return the nth Fibonacci number using recursion."""
    if n < 0:
        raise ValueError("Fibonacci is not defined for negative numbers")
    if n <= 1:
        return n
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)


def fibonacci_sequence(n):
    """Return a list containing the first n Fibonacci numbers (iterative)."""
    if n < 0:
        raise ValueError("n must be a non-negative integer")
    sequence = []
    a, b = 0, 1
    for _ in range(n):
        sequence.append(a)
        a, b = b, a + b
    return sequence


if __name__ == "__main__":
    count = int(input("Enter how many Fibonacci numbers to generate: "))
    print(f"First {count} Fibonacci numbers: {fibonacci_sequence(count)}")

    position = int(input("Enter a position to get a single Fibonacci number (recursive): "))
    print(f"Fibonacci number at position {position} = {fibonacci_recursive(position)}")
